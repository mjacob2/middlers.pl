var html = '<footer>\
<p class="footerText">\
    ○●○ middlers | mobilny doradca finansowy we Wrocławiu\
</p>\
<a class="footerText" href="https://middlers.pl/polityka-prywatnosci.html">Polityka prywatności</a>\
<a class="footerText" href="https://middlers.pl/polityka-cookies.html">Polityka cookies</a>\
<p class="footerText">\
    Middlers Sp. z o.o. z siedzibą we Wrocławiu ul. Leszczyńskiego 4/29, 50-078 Wrocław, zarejestrowana w Sądzie\
    Rejonowym dla Wrocławia-Fabrycznej KRS-532823, NIP-8971803272, REGON-360170795, kapitał zakładowy 5.000,00\
    zł.\
</p>\
</footer>';

document.getElementById('footerBar').innerHTML = html;